/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_163()
{
    return 3284633928U;
}

void setval_179(unsigned *p)
{
    *p = 2429000008U;
}

void setval_396(unsigned *p)
{
    *p = 2429004104U;
}

void setval_342(unsigned *p)
{
    *p = 2425641101U;
}

void setval_175(unsigned *p)
{
    *p = 3630501308U;
}

unsigned addval_252(unsigned x)
{
    return x + 2042859608U;
}

unsigned getval_315()
{
    return 3284633928U;
}

void setval_196(unsigned *p)
{
    *p = 2425393240U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_444(unsigned *p)
{
    *p = 3380924801U;
}

unsigned addval_438(unsigned x)
{
    return x + 3526935241U;
}

void setval_476(unsigned *p)
{
    *p = 2425409929U;
}

void setval_169(unsigned *p)
{
    *p = 2447411528U;
}

unsigned getval_140()
{
    return 3680551561U;
}

unsigned addval_166(unsigned x)
{
    return x + 3286272344U;
}

void setval_201(unsigned *p)
{
    *p = 3374370441U;
}

unsigned getval_168()
{
    return 3372797577U;
}

unsigned addval_428(unsigned x)
{
    return x + 3224948393U;
}

unsigned getval_402()
{
    return 3677408905U;
}

unsigned addval_178(unsigned x)
{
    return x + 3268512200U;
}

unsigned getval_314()
{
    return 2464188744U;
}

void setval_368(unsigned *p)
{
    *p = 3380923913U;
}

unsigned getval_230()
{
    return 3285289837U;
}

void setval_419(unsigned *p)
{
    *p = 3525362313U;
}

unsigned getval_258()
{
    return 3286239560U;
}

unsigned getval_449()
{
    return 3247493513U;
}

unsigned addval_401(unsigned x)
{
    return x + 3353381192U;
}

unsigned getval_106()
{
    return 3677934025U;
}

void setval_308(unsigned *p)
{
    *p = 3380924105U;
}

unsigned getval_122()
{
    return 3221799565U;
}

unsigned getval_489()
{
    return 2425409961U;
}

void setval_157(unsigned *p)
{
    *p = 3380920969U;
}

unsigned addval_161(unsigned x)
{
    return x + 3224945305U;
}

unsigned getval_450()
{
    return 3469315148U;
}

unsigned getval_247()
{
    return 3531918989U;
}

void setval_470(unsigned *p)
{
    *p = 3373843081U;
}

unsigned getval_280()
{
    return 2430634440U;
}

unsigned getval_126()
{
    return 3286272328U;
}

unsigned addval_487(unsigned x)
{
    return x + 3375944073U;
}

void setval_197(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_425(unsigned x)
{
    return x + 3351415042U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
