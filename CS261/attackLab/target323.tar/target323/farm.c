/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_296(unsigned *p)
{
    *p = 3625756786U;
}

void setval_458(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_134(unsigned x)
{
    return x + 3687012383U;
}

void setval_333(unsigned *p)
{
    *p = 2425387088U;
}

void setval_221(unsigned *p)
{
    *p = 2428995912U;
}

unsigned getval_460()
{
    return 2496104776U;
}

unsigned addval_431(unsigned x)
{
    return x + 3281031256U;
}

unsigned getval_202()
{
    return 2496104776U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_304(unsigned *p)
{
    *p = 3224949121U;
}

unsigned getval_212()
{
    return 3221279113U;
}

unsigned addval_181(unsigned x)
{
    return x + 3224948361U;
}

void setval_104(unsigned *p)
{
    *p = 3676881545U;
}

unsigned addval_293(unsigned x)
{
    return x + 3380924809U;
}

unsigned addval_136(unsigned x)
{
    return x + 3255430490U;
}

unsigned getval_127()
{
    return 2428668400U;
}

unsigned addval_299(unsigned x)
{
    return x + 3286273352U;
}

unsigned getval_373()
{
    return 851956105U;
}

unsigned getval_461()
{
    return 3286272360U;
}

unsigned addval_133(unsigned x)
{
    return x + 3767093843U;
}

void setval_347(unsigned *p)
{
    *p = 3285289367U;
}

void setval_409(unsigned *p)
{
    *p = 3374891657U;
}

unsigned addval_382(unsigned x)
{
    return x + 3281179017U;
}

unsigned addval_446(unsigned x)
{
    return x + 2430634312U;
}

unsigned addval_342(unsigned x)
{
    return x + 3286288712U;
}

unsigned addval_367(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_359()
{
    return 3229926041U;
}

unsigned getval_287()
{
    return 3264269961U;
}

void setval_416(unsigned *p)
{
    *p = 3374891657U;
}

void setval_470(unsigned *p)
{
    *p = 3268512000U;
}

unsigned getval_233()
{
    return 2496563588U;
}

unsigned getval_351()
{
    return 3372797576U;
}

unsigned addval_256(unsigned x)
{
    return x + 3263897287U;
}

void setval_390(unsigned *p)
{
    *p = 3524841097U;
}

void setval_194(unsigned *p)
{
    *p = 3523792520U;
}

unsigned addval_489(unsigned x)
{
    return x + 3281047177U;
}

unsigned getval_164()
{
    return 3286273352U;
}

unsigned addval_289(unsigned x)
{
    return x + 2430634312U;
}

void setval_235(unsigned *p)
{
    *p = 3676360969U;
}

unsigned getval_245()
{
    return 3677408905U;
}

void setval_200(unsigned *p)
{
    *p = 3526935177U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
