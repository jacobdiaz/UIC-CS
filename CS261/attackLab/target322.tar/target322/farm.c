/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_404(unsigned *p)
{
    *p = 2496104776U;
}

void setval_415(unsigned *p)
{
    *p = 2411892824U;
}

unsigned addval_372(unsigned x)
{
    return x + 1477261630U;
}

void setval_262(unsigned *p)
{
    *p = 3267856712U;
}

unsigned addval_260(unsigned x)
{
    return x + 3281017040U;
}

unsigned getval_411()
{
    return 3348140120U;
}

void setval_147(unsigned *p)
{
    *p = 3284633928U;
}

void setval_467(unsigned *p)
{
    *p = 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_302(unsigned *p)
{
    *p = 4106472065U;
}

void setval_287(unsigned *p)
{
    *p = 2446756250U;
}

void setval_288(unsigned *p)
{
    *p = 3372796553U;
}

unsigned getval_343()
{
    return 3286272328U;
}

void setval_413(unsigned *p)
{
    *p = 3374367113U;
}

void setval_259(unsigned *p)
{
    *p = 3285621023U;
}

void setval_256(unsigned *p)
{
    *p = 2495711501U;
}

void setval_455(unsigned *p)
{
    *p = 3375939993U;
}

unsigned getval_391()
{
    return 3767093460U;
}

void setval_221(unsigned *p)
{
    *p = 3385117321U;
}

unsigned addval_134(unsigned x)
{
    return x + 3525891721U;
}

unsigned addval_226(unsigned x)
{
    return x + 2462157308U;
}

void setval_113(unsigned *p)
{
    *p = 3380920713U;
}

unsigned addval_105(unsigned x)
{
    return x + 3286272344U;
}

unsigned getval_488()
{
    return 3532966537U;
}

void setval_442(unsigned *p)
{
    *p = 2425408137U;
}

unsigned getval_487()
{
    return 2430632264U;
}

void setval_257(unsigned *p)
{
    *p = 3229931145U;
}

unsigned addval_383(unsigned x)
{
    return x + 3281049217U;
}

void setval_430(unsigned *p)
{
    *p = 3229141641U;
}

unsigned addval_243(unsigned x)
{
    return x + 365019529U;
}

unsigned addval_301(unsigned x)
{
    return x + 3234120073U;
}

void setval_453(unsigned *p)
{
    *p = 2425476745U;
}

void setval_204(unsigned *p)
{
    *p = 2430635336U;
}

void setval_152(unsigned *p)
{
    *p = 2430634344U;
}

void setval_408(unsigned *p)
{
    *p = 3281046145U;
}

unsigned getval_145()
{
    return 2497743176U;
}

unsigned addval_479(unsigned x)
{
    return x + 2429978993U;
}

void setval_188(unsigned *p)
{
    *p = 3374893705U;
}

unsigned getval_456()
{
    return 3269495112U;
}

unsigned addval_246(unsigned x)
{
    return x + 2425471369U;
}

unsigned addval_319(unsigned x)
{
    return x + 3601401719U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
