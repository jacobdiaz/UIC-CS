-- 10. Compute the values from the previous for each color line, rather than only the Blue Line.
--     Averages before and after 3/1/2020 should still be computed on an individual station basis,
--     then averaged together to form the average for the line.
--     Keep in mind how you did question 1, joining across from stations to the line colors. 


