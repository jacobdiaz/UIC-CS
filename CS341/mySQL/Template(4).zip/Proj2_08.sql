-- 8.    Generate a table that shows the name of each station on the Blue Line, 
-- along with the calculated values for the previous question recomputed for each station
-- (PreCOVIDAvg, PostCOVIDAvg,  Decrease, and PercentDrop). 

