module project.thejakediaznetbeans {
    requires javafx.controls;
    exports project.thejakediaznetbeans;
}
