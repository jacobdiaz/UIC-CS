package project.thejakediaznetbeans;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void launch() {
    }

    @Test
    void testLaunch() {
    }

    @Test
    void init() {
    }

    @Test
    void stop() {
    }

    @Test
    void getHostServices() {
    }

    @Test
    void getParameters() {
    }

    @Test
    void notifyPreloader() {
    }

    @Test
    void getUserAgentStylesheet() {
    }

    @Test
    void setUserAgentStylesheet() {
    }

    @Test
    void setMenu_bar() {
    }

    @Test
    void check_won() {
    }

    @Test
    void set_buttons() {
    }

    @Test
    void start_game() {
    }

    @Test
    void intro() {
    }

    @Test
    void drawing() {
    }

    @Test
    void start() {
    }

    @Test
    void main() {
    }
}