package test.java;

import org.junit.jupiter.api.Test;

class test {
    @Test
    void testAddSugar(){}
    @Test
    void testAddCream(){}
    @Test
    void testAddExtraShot(){}
    @Test
    void testAddGuac(){}
    @Test
    void testAddOatMilk(){}
    @Test
    void testConfirmOrder(){}
    @Test
    void testDeleteOrder(){}
}